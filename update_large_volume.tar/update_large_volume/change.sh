#!/bin/bash

mv -f /etc/auditbeat/auditbeat.yml /etc/auditbeat/auditbeat.bk
mv -f /etc/auditbeat/audit.rules.d/audit.conf /etc/auditbeat/audit.rules.d/audit.bk

mv auditbeat.yml /etc/auditbeat/auditbeat.yml
mv audit.conf /etc/auditbeat/audit.rules.d/audit.conf

systemctl enable auditbeat
systemctl restart auditbeat